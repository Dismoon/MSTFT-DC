function [MSTFT] =MSTFT(s,sigma,bt,ft)
%   Computes the MSTFT of a signal with a Gaussian window.
%---------------------------------------------------------------
%   INPUTS:  
%   s: real or complex signal, must be of length 2^
%   sigma: window parameter
%   ft: frequency bins
%   bt: time bins
%---------------------------------------------------------------
%   OUTPUTS:   
%   MSTFT: modulated short-time Fourier transform of s

% checking length of signal
n = length(s);
nv = log2(n);
if mod(nv,1)~=0
    warning('The signal is not a power of two, truncation to the next power');
    s = s(1:2^floor(nv));
end
n = length(s);
s = s(:);

nb = length(bt);
neta = length(ft);

% Padding
sleft = flipud(s(2:n/2+1));
sright = flipud(s(end-n/2:end-1));
x = [sleft; s; sright];
clear xleft xright;

% Window definition
t = linspace(-0.5,0.5,n);t=t';
g = (1/((2*pi).^(1/2)*sigma))*exp(-1/(2*sigma^2)*t.^2);

% Initialization
MSTFT = zeros(neta,nb);

%% Computes MSTFT a
df = ft(2)-ft(1);
for b=1:nb
    tmp = (fft(x(bt(b):bt(b)+n-1).*g))/n;
    vg = tmp(ft);
    MSTFT(:,b) = vg.* exp(1i*pi*(ft-1)'); 
        
end
MSTFT = df*MSTFT;

