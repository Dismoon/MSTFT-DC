This code implements signal separation by modulated short-time Fourier transform. 

The main code 'demo' is an example that is a signal with two components.

The key parts of this code including MSTFT.m (modulated short-time Fourier transform)  and exridge_mult.m (extract local maximum curves).
The current version is not optimal. You can improve the performance of code by optimizing the algorithm .

The reference paper is as follows:

Modulated short-time Fourier transform based non-stationary signal decomposition for dual-comb ranging systems

The code is provided for research. If you encounter any problem using this code, please feel free to email：
ningninghan@tiangong.edu.cn. Thanks! 