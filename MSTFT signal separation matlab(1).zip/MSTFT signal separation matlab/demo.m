% Parameters
clear all;
close all;
clc;
%% Generate signal
addpath('utilities');
tolTrendFre=0.01;
N = 1024;
t = (0:N-1)/N;
phi1 = 40*t+20*t.^3-20*(1-t).^4;
phi2 = 330*t-2.*exp(-2*(t-0.4)).*sin(10*pi.*(t-0.4));
Signal1 = 0.5*exp(-(t-0.5).^2/50).*cos(2*pi*(phi1));
Signal2 = (0.25+0.25*cos(2*pi*t/4)).*cos(2*pi*(phi2));
delta=t(2)-t(1);
x = Signal1+Signal2;

figure;
plot(t,x,'g-');
axis([t(1),t(end),-1.5,1.5])
xlabel('Time')
ylabel('Amplitude')
title('Blind-source signal')
%---------------------------------------------------------------------------------------------------------
% inital parameters
sigma=0.005;  
nr=2;      % This parameter can be determined by time-frequency image of MSTFT

lambda=0.001;
clwin=100; % Parameters correspond to extract local maximum curve, it applied to most of cases.

bt = 1:N;
ft = 1:N/2; % Choice of time and frequency bins

%% modulated short-time Fourier transform of signal
[MSTFT] =MSTFT(x,sigma,bt,ft);

figure;
imagesc(abs(MSTFT));
colorbar

%% Extract local maximum curve
[Cs, Es] = exridge_mult(MSTFT, nr,lambda,clwin); % Extract the locations of components

%% Reconstruct sub-signals
for it=1:nr
    Index=Cs(it,:);
    TauVector=zeros(1,N);
    for l=1:N
        TauVector(l)=MSTFT(Index(l),l); % fix t, \TauF(t,thelta)
    end
    RecoverFrequency(:,it)=ft(Index)/(delta)/N;
    RecoverSignal(:,it)=2*real(TauVector); 
end

figure;
subplot(211)
plot(t,Signal1,'k-','LineWidth',1)
hold on;
plot(t,RecoverSignal(:,2),'b--','LineWidth',2.5);
ylabel('Amplitude');
legend('Ground truth','Recovered component')
axis([0 1 -1 1]);
xlabel('Time');
rectangle('Position',[0.2 -0.6 0.05,1.2],'edgecolor','r','LineWidth',2) 
subplot(212)
plot(t,Signal1,'k-','LineWidth',1)
hold on;
plot(t,RecoverSignal(:,2),'b--','LineWidth',2.5);
% legend('Ground truth','Recovered component')
axis([0.2 0.25 -0.5 0.5]);

figure;
subplot(211)
plot(t,Signal2,'k-','LineWidth',1)
hold on;
plot(t,RecoverSignal(:,1),'b--','LineWidth',2.5);
ylabel('Amplitude');
legend('Ground truth','Recovered component');
axis([0 1 -1 1]);
xlabel('Time');
rectangle('Position',[0.05 -0.6 0.05,1.2],'edgecolor','r','LineWidth',2) 
subplot(212)
plot(t,Signal2,'k-','LineWidth',1)
hold on;
plot(t,RecoverSignal(:,1),'b--','LineWidth',2.5);
% legend('Ground truth','Recovered component')
axis([0.05 0.1 -0.5 0.5]);
